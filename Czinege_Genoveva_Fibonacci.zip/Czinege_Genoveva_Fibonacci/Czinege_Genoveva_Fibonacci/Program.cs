﻿using System;

namespace Czinege_Genoveva_Fibonacci
{
    
    class Program
    {
        public static int fib(int N)
        {
            
            if (N == 0)
            {
               return  0;
            }
            else if(N==1)
            {
               return 1;
            }
            else
            {
                return fib(N - 1) + fib(N - 2);
            }
             
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hány elemű legyen? ");
            int db = int.Parse(Console.ReadLine());
            Console.Write("Érték: ");
            Console.WriteLine(fib(db-1));

            Console.WriteLine("Számok felsorolva: ");
            int a = 0;
            int b = 1;

            for (int i = 0; i < db; i++)
            {
                Console.Write("{0} ",a);
                int csere = a;
                a = b;
                b = csere + b;
            }
            Console.ReadKey();
        }
    }
}
